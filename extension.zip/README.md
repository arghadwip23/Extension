# online-classes-prank

To use it, download the repository as zip file, extract it, and then manually install it from chrome://extensions
